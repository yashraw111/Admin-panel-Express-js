const SubCategory = require("../model/subCategory.model");
exports.Store = async (req, res) => {
  try {
    const { cat_name, sub_category } = req.body;
 const sCategory=await SubCategory.create({cat_name, sub_category});
    res.json({
      success:true,
      message:sCategory
    })
  } catch (error) {
    res.json({message:true,error})
    console.log(error);
  }
};

exports.index=async(req,res)=>{
  try{
    const subCategory=await SubCategory.find().populate('Admin')
    res.json(subCategory)
  }catch(err){
    res.json(err)
  }
}