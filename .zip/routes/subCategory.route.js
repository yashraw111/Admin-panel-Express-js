const router = require('express').Router()

const subCategoryController = require("../controller/subCategory.controller");
router.post('/',subCategoryController.Store)
router.get('/',subCategoryController.index)

module.exports = router 